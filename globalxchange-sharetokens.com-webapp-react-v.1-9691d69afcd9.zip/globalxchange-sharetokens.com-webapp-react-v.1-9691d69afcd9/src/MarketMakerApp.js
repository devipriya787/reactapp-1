import Routes from "./Routes";
import "./static/scss/master.scss";
import "@teamforce/fullpage-search/dist/index.css";
import "@teamforce/coins-app/dist/index.css";
import ChatsContextProvider from "./context/ChatsContext";
import MainContextProvider from "./context/MainContext";

function App() {
  return (
    <MainContextProvider>
      <ChatsContextProvider>
        <Routes />
      </ChatsContextProvider>
    </MainContextProvider>
  );
}

export default App;
