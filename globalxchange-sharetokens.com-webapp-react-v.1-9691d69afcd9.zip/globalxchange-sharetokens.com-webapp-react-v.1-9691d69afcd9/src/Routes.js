import React from "react";
import { Switch, Route, BrowserRouter } from "react-router-dom";
import CoinPage from "./pages/CoinPage";
import HomePage from "./pages/HomePage";

function Routes() {
  return (
    <BrowserRouter>
      <Switch>
        <Route exact path="/" component={HomePage} />
        <Route exact path="/:pathId" component={CoinPage} />
      </Switch>
    </BrowserRouter>
  );
}

export default Routes;
