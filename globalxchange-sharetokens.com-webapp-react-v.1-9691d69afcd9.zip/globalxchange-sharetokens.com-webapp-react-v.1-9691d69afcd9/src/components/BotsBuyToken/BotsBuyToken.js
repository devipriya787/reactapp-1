import axios from "axios";
import React, { useContext, useEffect, useState } from "react";
import Scrollbars from "react-custom-scrollbars";
import Skeleton from "react-loading-skeleton";
import { ChatsContext } from "../../context/ChatsContext";
import { MainContext } from "../../context/MainContext";
import { FormatCurrency } from "../../Utils/FunctionTools";
import LoadingAnim from "../LoadingAnim/LoadingAnim";

function BotsBuyToken() {
  const { email, token } = useContext(MainContext);
  const { tokenData } = useContext(ChatsContext);
  const [appBalanceList, setAppBalanceList] = useState([]);
  const [app, setApp] = useState();
  const [coinType, setCoinType] = useState("crypto");
  const [coinList, setCoinList] = useState([]);
  const [coinSelected, setCoinSelected] = useState();
  const [tokenValue, setTokenValue] = useState("");
  const [convertValue, setConvertValue] = useState("");
  const [coinValue, setCoinValue] = useState("");
  const [coinListObject, setCoinListObject] = useState();
  const [isTokenValue, setIsTokenValue] = useState(false);
  const [successRes, setSuccessRes] = useState();
  const [loading, setLoading] = useState(false);
  const [appLoading, setAppLoading] = useState(false);
  const [coinLoading, setCoinLoading] = useState(false);
  useEffect(() => {
    setAppLoading(true);
    axios
      .get(
        `https://comms.globalxchange.com/gxb/apps/registered/user?email=${email}`
      )
      .then(({ data }) => {
        if (data.status) {
          setAppBalanceList(data.userApps);
        }
      })
      .finally(() => setAppLoading(false));
  }, [email]);
  useEffect(() => {
    if (app?.app_code) {
      setCoinLoading(true);
      axios
        .post(`https://comms.globalxchange.com/coin/vault/service/coins/get`, {
          app_code: app?.app_code,
          profile_id: app?.profile_id,
        })
        .then(({ data }) => {
          if (data.status) {
            setCoinList(data?.coins_data);
            let coinObj = {};
            data?.coins_data?.forEach((coin) => {
              coinObj[coin.coinSymbol] = coin;
            });
            setCoinListObject(coinObj);
          }
        })
        .finally(() => setCoinLoading(false));
    }
  }, [app]);

  function buyCoin(preview) {
    setLoading(true);
    axios
      .post("https://comms.globalxchange.com/coin/investment/path/execute", {
        email,
        token,
        app_code: app.app_code,
        profile_id: app.profile_id,
        path_id: tokenData?.path_id,
        user_pay_coin: coinSelected?.coinSymbol,
        pay_amount: isTokenValue ? undefined : coinValue,
        tokens_amount: isTokenValue ? tokenValue : undefined,
        stats: preview,
      })
      .then(({ data }) => {
        if (data.status) {
          if (preview) {
          } else {
            setSuccessRes(data);
          }
        } else {
          alert(data.message);
        }
      })
      .finally(() => setLoading(false));
  }

  function getContent() {
    switch (true) {
      case Boolean(successRes):
        return (
          <>
            <div className="title">Success</div>
            <p className="desc">
              You Just Exchanged{" "}
              {FormatCurrency(coinValue, coinSelected?.coinSymbol)}{" "}
              {coinSelected?.coinName} For {FormatCurrency(tokenValue)}{" "}
              {tokenData?.token_profile_data?.coinName}
            </p>
          </>
        );
      case Boolean(coinSelected):
        return (
          <Scrollbars className="genarateQuote">
            <div className="title">Generate Quote</div>
            <div className="group">
              <div className="label">You Are Investing</div>
              <div className="inpWrap">
                <input
                  type="number"
                  placeholder={FormatCurrency(0, coinSelected?.coinSymbol)}
                  value={coinValue}
                  min={0}
                  onChange={(e) => {
                    const { value } = e.target;
                    if (value) {
                      setCoinValue(value);
                      setConvertValue(
                        (value * coinSelected?.price.USD) /
                          coinListObject[tokenData.asset].price.USD
                      );
                      setTokenValue(
                        (value * coinSelected?.price.USD) /
                          coinListObject[tokenData.asset].price.USD /
                          tokenData?.token_price
                      );
                    } else {
                      setCoinValue("");
                      setConvertValue("");
                      setTokenValue("");
                    }
                    setIsTokenValue(false);
                  }}
                />
                <div className="coinBox">
                  <img src={coinSelected?.coinImage} alt="" />
                  <span>{coinSelected?.coinSymbol}</span>
                </div>
              </div>
            </div>
            <div className="group">
              <div className="label">Converting To</div>
              <div className="inpWrap">
                <input
                  type="number"
                  min={0}
                  value={convertValue}
                  onChange={(e) => {
                    const { value } = e.target;
                    if (value) {
                      setConvertValue(value);
                      setCoinValue(
                        (value * coinListObject[tokenData.asset].price.USD) /
                          coinSelected?.price.USD
                      );
                      setTokenValue(value / tokenData?.token_price);
                    } else {
                      setCoinValue("");
                      setConvertValue("");
                      setTokenValue("");
                    }
                    setIsTokenValue(false);
                  }}
                  placeholder={FormatCurrency(
                    0,
                    (coinListObject && coinListObject[tokenData.asset])
                      ?.coinSymbol
                  )}
                />
                <div className="coinBox">
                  <img
                    src={
                      (coinListObject && coinListObject[tokenData.asset])
                        ?.coinImage
                    }
                    alt=""
                  />
                  <span>
                    {
                      (coinListObject && coinListObject[tokenData.asset])
                        ?.coinSymbol
                    }
                  </span>
                </div>
              </div>
            </div>
            <div className="group">
              <div className="label">You Will Receive</div>
              <div className="inpWrap">
                <input
                  type="number"
                  min={0}
                  placeholder={FormatCurrency(0)}
                  value={tokenValue}
                  onChange={(e) => {
                    const { value } = e.target;
                    if (value) {
                      setTokenValue(value);
                      setConvertValue(value * tokenData?.token_price);
                      setCoinValue(
                        (value *
                          tokenData?.token_price *
                          coinListObject[tokenData.asset].price.USD) /
                          coinSelected?.price.USD
                      );
                    } else {
                      setCoinValue("");
                      setConvertValue("");
                      setTokenValue("");
                    }
                    setIsTokenValue(true);
                  }}
                />
                <div className="coinBox">
                  <img src={tokenData?.token_profile_data?.coinImage} alt="" />
                  <span>{tokenData?.token_profile_data?.coinSymbol}</span>
                </div>
              </div>
            </div>
            <div className="group">
              <button
                disabled={!(tokenValue || coinValue)}
                className="btBuy"
                onClick={() => {
                  buyCoin(false);
                }}
              >
                Buy {FormatCurrency(tokenValue)}{" "}
                {tokenData?.token_profile_data?.coinSymbol}{" "}
              </button>
            </div>
          </Scrollbars>
        );

      case Boolean(app):
        return (
          <>
            <div className="coinTypeTabs">
              <div
                className={`tabItm ${coinType === "crypto"}`}
                onClick={() => setCoinType("crypto")}
              >
                Crypto
              </div>
              <div
                className={`tabItm ${coinType === "fiat"}`}
                onClick={() => setCoinType("fiat")}
              >
                Fiat
              </div>
            </div>
            <Scrollbars
              className="coinListWrapper"
              renderThumbHorizontal={() => <div />}
              renderThumbVertical={() => <div />}
            >
              {coinLoading
                ? Array(6)
                    .fill("")
                    .map(() => (
                      <div className="coinItem">
                        <Skeleton className="coin" />
                        <Skeleton className="name" width={300} />
                      </div>
                    ))
                : coinList
                    .filter(
                      (coin) => coin.type === coinType
                      //   (coin.coinName
                      //     .toLowerCase()
                      //     .includes(searchStr.toLowerCase()) ||
                      //     coin.coinSymbol
                      //       .toLowerCase()
                      //       .includes(searchStr.toLowerCase()))
                    )
                    .map((coin) => (
                      <div
                        className="coinItem"
                        key={coin.coinSymbol}
                        onClick={() => setCoinSelected(coin)}
                      >
                        <img className="coin" src={coin.coinImage} alt="" />
                        <div className="name">{coin.coinName}</div>
                        <div className="value">
                          {FormatCurrency(coin.coinValue, coin.coinSymbol)}
                        </div>
                      </div>
                    ))}
            </Scrollbars>
          </>
        );
      default:
        return (
          <>
            <div className="headTitle">
              {tokenData?.token_profile_data?.coinName} Is Listed On The
              Following Platforms. Select The App You Wish To Buy It From?
            </div>
            <Scrollbars className="vaultList">
              {appLoading
                ? Array(6)
                    .fill("")
                    .map(() => (
                      <div className="app">
                        <svg viewBox="0 0 1 1" />
                        <Skeleton className="appIcn" />
                      </div>
                    ))
                : appBalanceList
                    .filter((app) => {
                      if (tokenData?.app_codes)
                        for (let i = 0; i < tokenData?.app_codes?.length; i++) {
                          if (app.app_code === tokenData?.app_codes[i])
                            return true;
                        }
                      return false;
                    })
                    .map((app) => (
                      <div
                        className="app"
                        key={app.app_code}
                        onClick={() => setApp(app)}
                      >
                        <svg viewBox="0 0 1 1" />
                        <img src={app?.app_icon} alt="" className="appIcn" />
                        <span>{app?.app_name}</span>
                      </div>
                    ))}
              <div className="app hide">
                <svg viewBox="0 0 1 1" />
              </div>
            </Scrollbars>
          </>
        );
    }
  }
  return (
    <div className="botsBuyToken">
      {getContent()}
      {loading && (
        <div className="loading">
          <LoadingAnim />
        </div>
      )}
    </div>
  );
}

export default BotsBuyToken;
