import {
  faEye,
  faEyeSlash,
  faSpinner,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import axios from "axios";
import React, { useContext, useState } from "react";
import OtpInput from "react-otp-input";

import textLogo from "../../static/images/logo/textLogo.svg";
import { MainContext } from "../../context/MainContext";

const otpRegex = new RegExp(/^\d*$/);

function ChatLogin() {
  const { login } = useContext(MainContext);
  const [emailId, setemailId] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState("");
  const [isReset, setIsReset] = useState(false);
  const [loading, setLoading] = useState(false);
  const [mfaEnabled, setMfaEnabled] = useState(false);
  const [pin, setPin] = useState("");

  const loginvalidate = (password, emailid) => {
    if (/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(emailid)) {
      setLoading(true);
      axios
        .post("https://gxauth.apimachine.com/gx/user/login", {
          email: emailid,
          password,
          totp_code: mfaEnabled ? pin.toString() : undefined,
        })
        .then((response) => {
          const { data } = response;
          if (data.status) {
            login(emailid, data.accessToken, data.idToken, data.deviceKey);
            setPassword("");
          } else if (data.mfa) {
            setMfaEnabled(true);
          } else {
            alert(data.message);
          }
        })
        .catch((error) => {
          alert(error.message ? error.message : "Some Thing Went Wrong!");
        })
        .finally(() => {
          setLoading(false);
        });
    } else {
      alert("Enter Valid EmailId");
    }
  };

  const pinValidator = (pinStr) => {
    if (otpRegex.test(pinStr)) setPin(pinStr);
  };

  return (
    <form
      className="_tDK2U chatLogin"
      onSubmit={(e) => {
        e.preventDefault();
        loginvalidate(password, emailId);
      }}
    >
      <img src={textLogo} alt="" className="logo" />
      {mfaEnabled ? (
        <OtpInput
          containerStyle="otpInputWrapper"
          value={pin}
          onChange={(otp) => pinValidator(otp)}
          numInputs={6}
          separator={<span> </span>}
          inputStyle="otpInput"
          shouldAutoFocus
        />
      ) : (
        <>
          <div className="group">
            <input
              type="text"
              name="email"
              value={emailId}
              onChange={(e) => setemailId(e.target.value)}
              required="required"
            />
            <span className="highlight" />
            <span className="bar" />
            <label>Email</label>
          </div>
          <div className="group">
            <input
              type={showPassword ? "text" : "password"}
              name="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required="required"
            />
            <span className="highlight" />
            <span className="bar" />
            <FontAwesomeIcon
              className="eye"
              onClick={() => {
                setShowPassword(!showPassword);
              }}
              icon={showPassword ? faEyeSlash : faEye}
            />
            <label>Password</label>
          </div>
          <div className="forgot" onClick={() => setIsReset(true)}>
            Forgot Your Password?
          </div>
          <div className="group">
            <button type="submit" disabled={loading} className="btnLogin">
              {loading ? <FontAwesomeIcon icon={faSpinner} spin /> : "Enter"}
            </button>
          </div>
        </>
      )}
    </form>
  );
}

export default ChatLogin;
