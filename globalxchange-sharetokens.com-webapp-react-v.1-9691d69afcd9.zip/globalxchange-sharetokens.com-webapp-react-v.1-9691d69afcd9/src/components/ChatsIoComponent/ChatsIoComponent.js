import React, { useContext } from "react";
import ChatsIoComponent from "@teamforce/chats.io-plugin";
import "@teamforce/chats.io-plugin/dist/index.css";

import logo from "../../static/images/logo/chatsLogo.svg";
import { ChatsContext } from "../../context/ChatsContext";
import { MainContext } from "../../context/MainContext";
import ChatLogin from "../ChatLogin/ChatLogin";
import BotsBuyToken from "../BotsBuyToken/BotsBuyToken";

function ChatsIoComponentM() {
  const { setChatOn, tabSelected, tokenData } = useContext(ChatsContext);
  const { email, token } = useContext(MainContext);
  return email ? (
    <ChatsIoComponent
      tabOpen={tabSelected}
      primaryColor="#002a51"
      secondaryColor="#e7e7e7"
      appCode="ice"
      logo={logo}
      onClose={() => setChatOn(false)}
      right={false}
      emailId={email}
      idToken={token}
      botComponent={tokenData && <BotsBuyToken />}
    />
  ) : (
    <ChatLogin />
  );
}

export default ChatsIoComponentM;
