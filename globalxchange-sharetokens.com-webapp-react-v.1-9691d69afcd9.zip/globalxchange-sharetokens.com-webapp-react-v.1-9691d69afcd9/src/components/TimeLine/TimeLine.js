import React, { useState } from "react";
import locationPin from "../../static/images/slider/pin.svg";
import TimeLineDateModal from "../TimeLineDateModal/TimeLineDateModal";

function TimeLine({ launchDate, lockDate, redeemDate, coinImage }) {
  const redeemDateTemp = redeemDate || lockDate + (lockDate - launchDate);
  const totalDays = redeemDateTemp - launchDate;
  const launchDays = lockDate - launchDate;
  const today = new Date().getTime();
  const completeDays = today - launchDate;
  const percent = (launchDays / totalDays) * 100;
  const completePercent = (completeDays / totalDays) * 100;
  const [timeLineModal, setTimeLineModal] = useState();
  return (
    <>
      <div className="sliderWrapper">
        <img
          src={locationPin}
          alt=""
          className="locPin"
          style={{
            left: `${completePercent}%`,
            right: `${100 - completePercent}%`,
          }}
          onClick={() => setTimeLineModal({ title: "Today", date: new Date() })}
        />
        <svg
          viewBox="0 0 584 27"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect
            className="redStart"
            width="4"
            height="13"
            transform="matrix(1 0 0 -1 0 13)"
            fill="#E7258E"
          />
          <rect
            className="redBar"
            width={parseInt((percent * 580) / 100)}
            height="9"
            transform="matrix(1 0 0 -1 2 9)"
            fill="#E7258E"
            fill-opacity="0.25"
          />
          <rect
            className="greenStart"
            width="4"
            height="9"
            transform={`matrix(1 0 0 -1 ${
              parseInt((percent * 580) / 100) - 2
            } 9)`}
            fill="#5ABEA0"
          />
          <rect
            className="greenBar"
            width={parseInt(((100 - percent) * 580) / 100)}
            height="9"
            transform={`matrix(1 0 0 -1 ${
              parseInt((percent * 580) / 100) + 2
            } 9)`}
            fill="#5ABEA0"
            fill-opacity="0.5"
          />
          <rect
            className="greenEnd"
            width="4"
            height="13"
            transform="matrix(1 0 0 -1 580 13)"
            fill="#002A51"
          />
          <text
            x="0"
            y="26"
            font-size="10px"
            fill="#002A51"
            fontFamily="Montserrat, Arial, Helvetica, sans-serif"
            fontWeight={500}
            onClick={() =>
              setTimeLineModal({ title: "Fund Launch", date: launchDate })
            }
          >
            Launch
          </text>
          <text
            x={parseInt((percent * 580) / 100)}
            y="26"
            font-size="10px"
            fill="#002A51"
            fontFamily="Montserrat, Arial, Helvetica, sans-serif"
            fontWeight={500}
            onClick={() =>
              setTimeLineModal({ title: "Fund Lock", date: lockDate })
            }
          >
            Lock
          </text>
          <text
            x="542"
            y="26"
            font-size="10px"
            fill="#002A51"
            fontFamily="Montserrat, Arial, Helvetica, sans-serif"
            fontWeight={500}
            onClick={() =>
              setTimeLineModal({ title: "Fund Redeem", date: redeemDateTemp })
            }
          >
            Redeem
          </text>
        </svg>
      </div>
      {timeLineModal && (
        <TimeLineDateModal
          coinImage={coinImage}
          date={timeLineModal.date}
          title={timeLineModal.title}
          onClose={() => setTimeLineModal()}
        />
      )}
    </>
  );
}

export default TimeLine;
