import React from "react";
import moment from "moment";

function TimeLineDateModal({ coinImage, date, title, onClose }) {
  return (
    <div className="timeLineDateModal">
      <div className="overlay" onClick={onClose} />
      <div className="timeline">
        <div className="head">
          <img src={coinImage} alt="" />
          <span>Timeline</span>
        </div>
        <div className="content">
          <div className="box">
            <div className="mon">{moment(date).format("MMM")}</div>
            <div className="day">{moment(date).format("DD")}</div>
            <div className="title">{title}</div>
          </div>
          <div className="box true">
            <div className="mon">{moment(date).format("MMM")}</div>
            <div className="day">{moment(date).format("DD")}</div>
            <div className="title">{title}</div>
          </div>
          <div className="box">
            <div className="mon">{moment(date).format("MMM")}</div>
            <div className="day">{moment(date).format("DD")}</div>
            <div className="title">{title}</div>
          </div>
        </div>
        <div className="footer">{moment().format("MMMM Do YYYY")}</div>
      </div>
    </div>
  );
}

export default TimeLineDateModal;
