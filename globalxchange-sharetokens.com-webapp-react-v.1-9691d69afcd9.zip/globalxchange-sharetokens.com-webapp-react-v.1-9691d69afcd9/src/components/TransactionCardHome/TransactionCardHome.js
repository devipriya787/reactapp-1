import React, { useContext, useEffect, useState } from "react";
import { ChatsContext } from "../../context/ChatsContext";
import {
  FormatCurrency,
  FormatNumber,
  toFixed,
} from "../../Utils/FunctionTools";
import CoinSelectModal from "../CoinSelectModal/CoinSelectModal";

function TransactionCardHome({ coin, setCoin, coinList, data }) {
  const token = data?.token_profile_data;
  const rate = data?.pre_lock_token_price;
  const { setChatOn, setTokenData } = useContext(ChatsContext);
  const [tab, setTab] = useState("Buy");
  const [openModal, setOpenModal] = useState(false);
  const [tokenValue, setTokenValue] = useState(1);
  const [coinValue, setCoinValue] = useState("");
  const [spendValueFull, setSpendValueFull] = useState(false);
  const [coinValueFull, setCoinValueFull] = useState(false);

  function onTokenValueChange(value) {
    setTokenValue(value);
    setCoinValue(
      spendValueFull
        ? toFixed((value * rate) / coin?.usd_price)
        : FormatCurrency((value * rate) / coin?.usd_price, coin?.coinSymbol)
    );
  }

  function onCoinValueChange(value) {
    setCoinValue(value);
    setTokenValue(
      coinValueFull
        ? toFixed((value * coin?.usd_price) / rate)
        : FormatNumber((value * coin?.usd_price) / rate, 3)
    );
  }
  useEffect(() => {
    onCoinValueChange(coinValue);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [coinValueFull]);
  useEffect(() => {
    onTokenValueChange(tokenValue);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [spendValueFull]);

  return (
    <>
      <div className="transactionCard">
        <div className="tabs">
          <div className={`tab ${tab === "Buy"}`} onClick={() => setTab("Buy")}>
            Buy
          </div>
          <div
            className={`tab ${tab === "Stake"}`}
            // onClick={() => setTab("Stake")}
          >
            Stake
          </div>
          <div
            className={`tab ${tab === "Win"}`}
            //  onClick={() => setTab("Win")}
          >
            Win
          </div>
        </div>
        <div className="contents">
          <div className="group">
            <div className="label">
              You Are Spending
              {spendValueFull ? (
                <span onClick={() => setSpendValueFull(!spendValueFull)}>
                  Show Less
                </span>
              ) : (
                <span onClick={() => setSpendValueFull(!spendValueFull)}>
                  Show Full
                </span>
              )}
            </div>
            <label className="inpWraper">
              <input
                type="number"
                placeholder={`${
                  coin?.symbol.length < 3 ? coin?.symbol : ""
                }${FormatCurrency(0, coin?.coinSymbol)}`}
                value={coinValue}
                onChange={(e) => {
                  const { value } = e.target;
                  onCoinValueChange(value);
                }}
              />
              <div className="coin btns" onClick={() => setOpenModal(true)}>
                <img src={coin?.coinImage} alt="" />
                <span>{coin?.coinSymbol}</span>
              </div>
            </label>
          </div>
          <div className="group">
            <div className="label">
              You Are Receiving{" "}
              {coinValueFull ? (
                <span onClick={() => setCoinValueFull(!coinValueFull)}>
                  Show Less
                </span>
              ) : (
                <span onClick={() => setCoinValueFull(!coinValueFull)}>
                  Show Full
                </span>
              )}
            </div>
            <label className="inpWraper">
              <input
                type="number"
                placeholder="1.000"
                value={tokenValue}
                onChange={(e) => {
                  const { value } = e.target;
                  onTokenValueChange(value);
                }}
              />
              <div className="coin">
                <img src={token?.coinImage} alt="" />
                <span>{token?.coinSymbol}</span>
              </div>
            </label>
          </div>
        </div>
        <div className="ftBtns">
          <div className="btFees">Fees</div>
          <div
            className="btBuy"
            onClick={() => {
              setChatOn(true);
              setTokenData(data);
            }}
          >
            Buy
          </div>
        </div>
      </div>
      {openModal && (
        <CoinSelectModal
          coinList={coinList}
          setCoin={setCoin}
          onClose={() => setOpenModal(false)}
        />
      )}
    </>
  );
}

export default TransactionCardHome;
