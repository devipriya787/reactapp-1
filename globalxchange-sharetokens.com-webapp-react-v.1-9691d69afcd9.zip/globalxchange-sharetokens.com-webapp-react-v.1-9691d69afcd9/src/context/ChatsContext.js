import React, { createContext, useEffect, useState } from "react";

export const ChatsContext = createContext();
function ChatsContextProvider({ children }) {
  const [chatOn, setChatOn] = useState(false);
  const [tokenData, setTokenData] = useState();
  const [tabSelected, setTabSelected] = useState();
  useEffect(() => {
    if (!chatOn) {
      setTabSelected();
      setTokenData();
    } else if (tokenData) {
      setTabSelected("bot");
    }
  }, [tokenData, chatOn]);
  return (
    <ChatsContext.Provider
      value={{
        chatOn,
        setChatOn,
        tokenData,
        setTokenData,
        tabSelected,
        setTabSelected,
      }}
    >
      {children}
    </ChatsContext.Provider>
  );
}

export default ChatsContextProvider;
