import axios from "axios";
import React, { createContext, useEffect, useState } from "react";

export const MainContext = createContext();
function MainContextProvider({ children }) {
  const [email, setEmail] = useState(
    localStorage.getItem("chatsIoLoginAccount") || ""
  );
  const [accessToken, setAccessToken] = useState(
    localStorage.getItem("chatsIoAccessToken") || ""
  );
  const [idToken, setIdToken] = useState(
    localStorage.getItem("chatsIoIdToken") || ""
  );

  useEffect(() => {
    localStorage.setItem("chatsIoLoginAccount", email);
  }, [email]);
  useEffect(() => {
    localStorage.setItem("chatsIoAccessToken", accessToken);
  }, [accessToken]);
  useEffect(() => {
    localStorage.setItem("chatsIoIdToken", idToken);
  }, [idToken]);

  useEffect(() => {
    if (email && idToken) {
      axios
        .post("https://comms.globalxchange.com/coin/verifyToken", {
          email,
          token: idToken,
        })
        .then((res) => (res.data.status ? "" : login("", "", "")));
    }
  }, [email, idToken]);

  const login = (paramEmail, paramAccessToken, paramIdToken) => {
    setEmail(paramEmail);
    setAccessToken(paramAccessToken);
    setIdToken(paramIdToken);
  };
  return (
    <MainContext.Provider value={{ email, token: idToken, login }}>
      {children}
    </MainContext.Provider>
  );
}

export default MainContextProvider;
