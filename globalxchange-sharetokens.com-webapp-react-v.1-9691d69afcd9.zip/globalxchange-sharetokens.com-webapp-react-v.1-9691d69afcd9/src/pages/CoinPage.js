import React, { useContext, useEffect, useRef, useState } from "react";
import moment from "moment";
import { FooterFlipCards } from "@teamforce/coins-app";
import { MainLayout, MainNavbar } from "@teamforce/fullpage-search";

import mmIcon from "../static/images/logo/mmIcon.svg";
import ChatsIoComponentM from "../components/ChatsIoComponent/ChatsIoComponent";
import { ChatsContext } from "../context/ChatsContext";
import useWindowDimensions from "../Utils/WindowSize";
import profiles from "../static/images/logo/profiles.svg";
import oppertunities from "../static/images/logo/oppertunities.svg";
import terminals from "../static/images/logo/terminals.svg";
import virtualProspectus from "../static/images/logo/virtualProspectus.svg";
import textLogo from "../static/images/logo/textLogo.svg";

import { useHistory, useParams } from "react-router";
import TransactionCardHome from "../components/TransactionCardHome/TransactionCardHome";
import axios from "axios";
import CoinSelectModal from "../components/CoinSelectModal/CoinSelectModal";
import { FormatNumber } from "../Utils/FunctionTools";
import Skeleton from "react-loading-skeleton";
import TimeLine from "../components/TimeLine/TimeLine";

function CoinPage() {
  const history = useHistory();
  const { chatOn, setChatOn, setTokenData } = useContext(ChatsContext);
  const { height } = useWindowDimensions();
  const { pathId } = useParams();
  const [openModal, setOpenModal] = useState(false);
  const [coinList, setCoinList] = useState([]);
  const [coin, setCoin] = useState();
  const [coinBuy, setCoinBuy] = useState();
  const [pathData, setPathData] = useState();
  const [pathLoading, setPathLoading] = useState(false);
  const footerCards = [
    {
      label: "Prospectus",
      logo: virtualProspectus,
      background: "#002A51",
      onClick: () =>
        window.open(`https://virtualprospectus.com/${pathId}`, "_blank").focus,
    },
    {
      label: "Trading",
      logo: terminals,
      background: "#292929",
    },
    {
      label: "Partnerships",
      logo: oppertunities,
      background: "#5ABEA0",
    },
    {
      label: "Background",
      logo: profiles,
      background: "#3E56DD",
    },
  ];
  useEffect(() => {
    setPathLoading(true);
    axios
      .get(
        `https://comms.globalxchange.com/coin/investment/path/get?path_id=${pathId}`
      )
      .then(({ data }) => {
        if (data.status) {
          setPathData(data.paths[0]);
        }
      })
      .finally(() => setPathLoading(false));
  }, [pathId]);
  useEffect(() => {
    axios
      .get("https://comms.globalxchange.com/coin/vault/get/all/coins")
      .then(({ data }) => {
        if (data.status) {
          setCoinList(data.coins);
          const cCoin = data.coins.filter(
            (coin) => coin.coinSymbol === pathData?.asset
          )[0];
          setCoin(cCoin);
          setCoinBuy(cCoin);
        }
      });
  }, [pathData]);
  const [index, setIndex] = useState(0);

  const isPrev = (i) => {
    if (index === 0) {
      if (i === footerCards.length - 1) return true;
    } else {
      if (i === index - 1) return true;
    }
    return false;
  };
  const isNext = (i) => {
    if (index === footerCards.length - 1) {
      if (i === 0) return true;
    } else {
      if (i === index + 1) return true;
    }
    return false;
  };

  return (
    <MainLayout chatOn={chatOn} chatComponent={<ChatsIoComponentM />}>
      <div
        className="coinPage"
        style={{ height }}
        onClick={() => {
          if (chatOn) setChatOn(false);
        }}
      >
        <MainNavbar
          className=""
          logo={textLogo}
          onLogoClick={() => history.push("/")}
          chatOn={chatOn}
          setChatOn={setChatOn}
          btIcon={mmIcon}
          onBtClick={() => {}}
          btLabel="Markets Apps"
        />
        <div className={`pageContents ${chatOn}`}>
          <div className="titleDesc">
            {pathLoading ? (
              <Skeleton className="title" />
            ) : (
              <div className="title">
                <img src={pathData?.token_profile_data.coinImage} alt="" />
                {pathData?.token_profile_data.coinName}
              </div>
            )}
            {pathLoading ? (
              <Skeleton className="titleSm" />
            ) : (
              <div className="titleSm">Powered By {pathData?.banker}</div>
            )}
            <p>
              {pathLoading ? (
                <Skeleton count={2} />
              ) : (
                pathData?.token_profile_data.coinDescription
              )}
            </p>
            {pathData?.pathType === "contract" ? (
              <>
                <div className="btWrap">
                  <div className="head">
                    <span>Today</span>
                    <span>{moment().format("MMM Do YYYY")}</span>
                  </div>
                  <div className="btRates">
                    <div className="coin" onClick={() => setOpenModal(true)}>
                      <img src={coin?.coinImage} alt="" />
                      <span>{coin?.coinSymbol}</span>
                    </div>
                    <span className="value">
                      {FormatNumber(pathData?.token_price / coin?.usd_price, 4)}
                      {/* <small>+(0.00%)</small> */}
                    </span>
                  </div>
                </div>
                <TimeLine
                  launchDate={pathData?.timestamp}
                  lockDate={pathData?.lockup_timestamp}
                  coinImage={pathData?.token_profile_data?.coinImage}
                />
              </>
            ) : (
              <div className="coinDataGroup">
                <div className="coinData">
                  <div className="label">Market Cap</div>
                  <div className="wrap">
                    <span className="value">
                      {coin?.symbol.length < 3 ? coin?.symbol : ""}
                      {FormatNumber(
                        pathData?.asset_balance / coin?.usd_price,
                        4
                      )}
                    </span>
                    <div className="coin" onClick={() => setOpenModal(true)}>
                      <img src={coin?.coinImage} alt="" />
                      <span>{coin?.coinSymbol}</span>
                    </div>
                  </div>
                </div>
                <div className="coinData">
                  <div className="label">Tokens Sold</div>
                  <div className="wrap">
                    <span className="value">
                      {coin?.symbol.length < 3 ? coin?.symbol : ""}
                      {FormatNumber(pathData?.tokens_sold / coin?.usd_price, 4)}
                    </span>
                    <div className="coin" onClick={() => setOpenModal(true)}>
                      <img src={coin?.coinImage} alt="" />
                      <span>{coin?.coinSymbol}</span>
                    </div>
                  </div>
                </div>
                <div className="coinData">
                  <div className="label">Live Price</div>
                  <div className="wrap">
                    <span className="value">
                      {coin?.symbol.length < 3 ? coin?.symbol : ""}
                      {FormatNumber(pathData?.token_price / coin?.usd_price, 4)}
                    </span>
                    <div className="coin" onClick={() => setOpenModal(true)}>
                      <img src={coin?.coinImage} alt="" />
                      <span>{coin?.coinSymbol}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
          <div className="cardWrapper">
            <TransactionCardHome
              data={pathData}
              coin={coinBuy}
              setCoin={setCoinBuy}
              coinList={coinList}
            />
          </div>
        </div>
        <FooterFlipCards footerCards={footerCards} />
        <div className="mobileView">
          {pathLoading ? (
            <Skeleton className="title" />
          ) : (
            <div className="title">
              <img src={pathData?.token_profile_data.coinImage} alt="" />
              {pathData?.token_profile_data.coinName}
            </div>
          )}
          {pathLoading ? (
            <Skeleton className="titleSm" />
          ) : (
            <div className="titleSm">Powered By {pathData?.banker}</div>
          )}
          <div className="btWrap">
            <div className="btRates">
              <div className="coin" onClick={() => setOpenModal(true)}>
                <img src={coin?.coinImage} alt="" />
                <span>{coin?.coinSymbol}</span>
              </div>
              <span className="value">
                {FormatNumber(pathData?.token_price / coin?.usd_price, 4)}
                {/* <small>+(0.00%)</small> */}
              </span>
            </div>
          </div>
          <div className="carousel-horiz">
            {footerCards.map((arcade, i) => {
              return (
                <div
                  className={`card ${
                    index === i
                      ? "active"
                      : isPrev(i)
                      ? "prev"
                      : isNext(i)
                      ? "next"
                      : "inactive"
                  }`}
                  key={i}
                  onClick={() => setIndex(i)}
                  style={{ backgroundColor: arcade.background }}
                >
                  <img src={arcade.logo} alt="" />
                </div>
              );
            })}
          </div>
          <div className="btns">
            <div className="btQuote">Quote</div>
            <div
              className="btBuy"
              onClick={() => {
                setChatOn(true);
                setTokenData(pathData);
              }}
            >
              Buy
            </div>
          </div>
        </div>
      </div>
      {openModal && (
        <CoinSelectModal
          coinList={coinList}
          setCoin={setCoin}
          onClose={() => setOpenModal(false)}
        />
      )}
    </MainLayout>
  );
}

export default CoinPage;
