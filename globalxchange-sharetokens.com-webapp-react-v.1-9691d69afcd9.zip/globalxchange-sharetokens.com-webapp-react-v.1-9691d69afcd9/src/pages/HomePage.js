import React, { useContext, useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import {
  SearchBarSingle,
  CategoryModal,
  MainLayout,
  MainNavbar,
  SearchView,
} from "@teamforce/fullpage-search";
import Scrollbars from "react-custom-scrollbars";
import Axios from "axios";
import Skeleton from "react-loading-skeleton";

import ChatsIoComponentM from "../components/ChatsIoComponent/ChatsIoComponent";
import logo from "../static/images/logo/tokenTressury.svg";
import mmIcon from "../static/images/logo/mmIcon.svg";
import textLogo from "../static/images/logo/textLogo.svg";
import useWindowDimensions from "../Utils/WindowSize";
import { ChatsContext } from "../context/ChatsContext";
import eqtIcon from "../static/images/categoryIcons/equities.svg";
import fundsicon from "../static/images/categoryIcons/fundsicon.svg";
import syndicatesIcn from "../static/images/categoryIcons/syndicates.svg";
import rewards from "../static/images/categoryIcons/rewards.svg";
import LoyaltyComingSoon from "../components/LoyaltyComingSoon/LoyaltyComingSoon";

function HomePage() {
  const { height } = useWindowDimensions();
  const history = useHistory();
  const { chatOn, setChatOn } = useContext(ChatsContext);
  const [search, setSearch] = useState("");
  const [searchOn, setSearchOn] = useState(false);
  const [tab, setTab] = useState();
  const [tabIndex, setTabIndex] = useState(0);
  const [comingSoon, setComingSoon] = useState(false);
  const [pathLoading, setPathLoading] = useState(false);
  const [loading, setLoading] = useState(false);

  const [fundCoins, setFundCoins] = useState([]);
  const [equities, setEquities] = useState([]);
  const [fundLoading, setFundLoading] = useState(false);
  const [eqtLoading, setEqtLoading] = useState(false);
  useEffect(() => {
    setFundLoading(true);
    Axios.get(
      "https://comms.globalxchange.com/coin/investment/path/get?pathType=contract"
    )
      .then(({ data }) => {
        setFundCoins(data.paths);
      })
      .finally(() => setFundLoading(false));
  }, []);
  useEffect(() => {
    setEqtLoading(true);
    Axios.get(
      "https://comms.globalxchange.com/coin/investment/path/get?investmentType=EQT"
    )
      .then(({ data }) => {
        setEquities(data.paths);
      })
      .finally(() => setEqtLoading(false));
  }, []);
  const [bankers, setBankers] = useState([]);
  const [bankersLoading, setBankersLoading] = useState(false);
  useEffect(() => {
    setBankersLoading(true);
    Axios.get(
      "https://comms.globalxchange.com/coin/investment/path/banker/data"
    )
      .then(({ data }) => {
        setBankers(data.bankers);
      })
      .finally(() => setBankersLoading(false));
  }, []);

  const [syndicates, setSyndicates] = useState([]);
  const [syndicateLoading, setSyndicateLoading] = useState(false);
  useEffect(() => {
    setSyndicateLoading(true);
    Axios.get(
      "https://comms.globalxchange.com/coin/investment/path/get?pathType=eternalContract"
    )
      .then(({ data }) => {
        setSyndicates(data.paths);
      })
      .finally(() => setSyndicateLoading(false));
  }, []);

  function getSearchViewList() {
    let searchList = [];
    switch (tab) {
      case "Funds":
        fundCoins?.forEach((path, i) => {
          searchList.push({
            _id: path._id,
            logo: path.token_profile_data.coinImage,
            text: path.token_profile_data.coinName,
            subText: path.token_profile_data?.coinSymbol,
            obj: path,
            onClick: () => {
              history.push(`/${path.path_id}`);
            },
            status: path.path_status,
          });
        });
        return searchList;
      case "Shares":
        equities?.forEach((path, i) => {
          searchList.push({
            _id: path._id,
            logo: path.token_profile_data.coinImage,
            text: path.token_profile_data.coinName,
            subText: path.token_profile_data?.coinSymbol,
            obj: path,
            onClick: () => {
              history.push(`/${path.path_id}`);
            },
            status: path.path_status,
          });
        });
        return searchList;
      case "Loyalty":
        return [];
      case "Syndicates":
        syndicates?.forEach((path, i) => {
          searchList.push({
            _id: path._id,
            logo: path.token_profile_data.coinImage,
            text: path.token_profile_data.coinName,
            subText: path.token_profile_data?.coinSymbol,
            obj: path,
            onClick: () => {
              history.push(`/${path.path_id}`);
            },
            status: path.path_status,
          });
        });
        return searchList;
      default:
        return [];
    }
  }
  function getLoading() {
    switch (tab) {
      case "Funds":
        return fundLoading;
      case "Shares":
        return eqtLoading;
      case "Loyalty":
        return [];
      case "Syndicates":
        return bankersLoading;
      default:
        return true;
    }
  }
  const categorys = [
    {
      img: fundsicon,
      label: "Funds",
      onClick: () => {
        setTab("Funds");
        setTabIndex(0);
      },
      selected: tab === "Funds",
      placeholder: "Find A FundCoin",
    },
    {
      img: eqtIcon,
      label: "Shares",
      onClick: () => {
        setTab("Shares");
        setTabIndex(1);
      },
      selected: tab === "Shares",
      placeholder: "Find ShareTokens",
    },
    {
      img: syndicatesIcn,
      label: "Syndicates",
      onClick: () => {
        setTab("Syndicates");
        setTabIndex(2);
      },
      selected: tab === "Syndicates",
      placeholder: "Find a Syndicate Fund",
    },
    {
      img: rewards,
      label: "Loyalty",
      onClick: () => {
        // setTab("Loyalty");
        // setTabIndex(2);
        setComingSoon(true);
      },
      selected: tab === "Loyalty",
      placeholder: "Find Loyalty Tokens",
    },
  ];

  useEffect(() => {
    if (search) setSearchOn(true);
  }, [search]);

  useEffect(() => {
    setTab(categorys[tabIndex]?.label);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tabIndex]);

  const [categoryModal, setCategoryModal] = useState(false);

  return (
    <>
      {searchOn ? (
        <SearchView
          search={search}
          setSearch={setSearch}
          placeholder={categorys[tabIndex]?.placeholder}
          iconOne={{
            icon: categorys[tabIndex]?.img,
            label: categorys[tabIndex]?.label,
            onClick: () => {
              setCategoryModal(true);
            },
            active: true,
          }}
          iconTwo={{}}
          loading={loading}
          appLogo={mmIcon}
          searchList={getSearchViewList()}
          goBack={() => setSearchOn(false)}
        />
      ) : (
        <MainLayout chatOn={chatOn} chatComponent={<ChatsIoComponentM />}>
          <div className="landingPage" style={{ height }}>
            <MainNavbar
              className=""
              logo={textLogo}
              onLogoClick={() => history.push("/")}
              chatOn={chatOn}
              setChatOn={setChatOn}
              btIcon={mmIcon}
              onBtClick={() => {}}
              btLabel="Markets Apps"
            />
            <div className="banker" onClick={() => chatOn && setChatOn(false)}>
              <p className="main-title">The Future Is Tokenized</p>
              <p className="sub-title">
                Discover The Latest Tokenized Assets Across A Variety Of
                Industries
              </p>
              <SearchBarSingle
                search={search}
                setSearch={setSearch}
                placeholder={categorys[tabIndex]?.placeholder}
                iconOne={{
                  icon: categorys[tabIndex]?.img,
                  name: categorys[tabIndex]?.label,
                  onClick: () => {
                    setCategoryModal(true);
                  },
                }}
                appLogo={logo}
                searchList={[]}
                goBack={() => {
                  console.log("click");
                }}
              />
            </div>
            <div className="titles">
              {categorys.map((inv, i) => (
                <span
                  key={inv.key}
                  className={`user ${tab === inv.label}`}
                  onClick={() => {
                    inv.onClick();
                  }}
                >
                  {inv.label}
                </span>
              ))}
            </div>
            {categorys.length && (
              <div className="titlesScroll">
                <span
                  className="btns"
                  onClick={() => setTabIndex((i) => (i - 1 === -1 ? 3 : i - 1))}
                >
                  {categorys[tabIndex - 1 === -1 ? 3 : tabIndex - 1].label}
                </span>
                <span className="selected">{categorys[tabIndex].label}</span>
                <span
                  className="btns"
                  onClick={() => setTabIndex((i) => (i + 1 === 4 ? 0 : i + 1))}
                >
                  {categorys[tabIndex + 1 === 4 ? 0 : tabIndex + 1].label}
                </span>
              </div>
            )}
            <div className="footer-winners-wrapper">
              <Scrollbars
                renderTrackHorizontal={(props) => <div {...props}></div>}
                renderThumbHorizontal={(props) => <div></div>}
                renderView={(props) => (
                  <div {...props} className="footer-winners" />
                )}
              >
                {getLoading()
                  ? Array(20)
                      .fill("")
                      .map((_, i) => (
                        <div className="winner" key={i}>
                          <Skeleton className="icon" circle />
                        </div>
                      ))
                  : getSearchViewList()
                      ?.filter(
                        (path) =>
                          path.text
                            ?.toLowerCase()
                            .includes(search.toLowerCase()) ||
                          path.subText
                            ?.toLowerCase()
                            .includes(search.toLowerCase())
                      )
                      .map((path) => (
                        <div
                          className="winner new"
                          onClick={() => path?.onClick()}
                          key={path._id}
                        >
                          <img src={path?.logo} alt="" className="icon" />
                          <div className="name">{path?.text}</div>
                          <div className={`status ${path.status}`} />
                        </div>
                      ))}
              </Scrollbars>
            </div>
          </div>
        </MainLayout>
      )}
      {categoryModal && (
        <CategoryModal
          categories={categorys}
          onClose={() => setCategoryModal(false)}
          label={"Select Token Type"}
        />
      )}
      {comingSoon && <LoyaltyComingSoon onClose={() => setComingSoon(false)} />}
    </>
  );
}

export default HomePage;
